"""
NeuroRest - Sleep Recovery & Cognitive Performance Predictor
Full-featured Flask backend with all 10 features
"""

from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import math
import json
import os
from datetime import datetime, timedelta
from pathlib import Path

app = Flask(__name__)
CORS(app)

DATA_FILE = "sleep_data.json"

# ─────────────────────────────────────────────────────────
#  DATA PERSISTENCE (file-based, no DB required)
# ─────────────────────────────────────────────────────────

def load_data():
    if Path(DATA_FILE).exists():
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {"logs": [], "rewards": {"points": 0, "streak": 0, "last_log_date": None}}

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ─────────────────────────────────────────────────────────
#  CORE ALGORITHMS
# ─────────────────────────────────────────────────────────

RECOMMENDED_SLEEP = 8.0

def circadian_modifier(hour: int) -> float:
    """Dual-Gaussian circadian alertness curve. Range: 0.70–1.15"""
    morning = math.exp(-0.5 * ((hour - 10) / 3) ** 2)
    evening = math.exp(-0.5 * ((hour - 19) / 2.5) ** 2)
    raw = 0.6 * morning + 0.4 * evening
    return round(0.70 + 0.45 * raw, 4)

def compute_sleep_debt(logs: list) -> dict:
    """
    Compute cumulative sleep debt from history with 85% daily decay.
    Returns debt value and recovery estimate.
    """
    debt = 0.0
    for log in logs[-14:]:  # use last 14 days
        deficit = max(0, RECOMMENDED_SLEEP - log.get("sleep_hours", 0))
        debt = (debt + deficit) * 0.85
    debt = round(debt, 2)

    # Recovery: each extra hour beyond 8h reduces debt at 50% efficiency
    recovery_nights = 0
    if debt > 0:
        sim_debt = debt
        while sim_debt > 0.25 and recovery_nights < 14:
            sim_debt = max(0, (sim_debt - 1.0) * 0.85)
            recovery_nights += 1

    return {
        "sleep_debt_hours": debt,
        "recovery_nights": recovery_nights,
        "status": "No debt" if debt == 0 else (
            "Mild" if debt < 2 else "Moderate" if debt < 5 else "Severe"
        )
    }

def caffeine_boost(mg: float, hours_ago: float) -> float:
    if mg <= 0: return 0.0
    remaining = mg * (0.5 ** (hours_ago / 5.0))
    return round(min(12, (remaining / 400) * 12), 2)

def stress_penalty(level: int) -> float:
    if level <= 3: return level * 1.5
    elif level <= 6: return 4.5 + (level - 3) * 3.5
    else: return 15 + (level - 6) ** 1.8 * 2.5

def predict_reaction_time(score: float) -> dict:
    """
    Reaction time degrades as cognitive score falls.
    Baseline: 250ms at score=100. Degrades to ~600ms at score=0.
    """
    baseline = 250
    # Exponential degradation
    predicted = baseline + (1 - score / 100) ** 1.6 * 350
    predicted = round(predicted)
    pct_slower = round((predicted - baseline) / baseline * 100, 1)
    risk = "Safe" if predicted < 320 else (
        "Caution" if predicted < 420 else "High Risk"
    )
    return {
        "baseline_ms": baseline,
        "predicted_ms": predicted,
        "pct_slower": pct_slower,
        "risk_level": risk,
        "driving_safe": predicted < 380
    }

def fatigue_risk(score: float) -> str:
    if score >= 80: return "Optimal"
    if score >= 60: return "Mild Fatigue"
    if score >= 40: return "Moderate Fatigue"
    return "Severe Fatigue"

def compute_cognitive_score(sleep_hours, debt, caffeine_mg, hours_since_caff, stress, hour) -> dict:
    sleep_ratio = sleep_hours / RECOMMENDED_SLEEP
    base = 100 / (1 + math.exp(-6 * (sleep_ratio - 0.8)))
    base = min(100, max(0, base))

    debt_pen = min(35, debt * 4.2)
    caff = caffeine_boost(caffeine_mg, hours_since_caff)
    s_pen = stress_penalty(stress)
    circ = circadian_modifier(hour)

    raw = (base - debt_pen + caff - s_pen) * circ
    score = round(min(100, max(0, raw)), 1)
    productivity = round(score * 0.92, 1)  # slight offset from pure cognition

    return {
        "cognitive_score": score,
        "fatigue_risk": fatigue_risk(score),
        "productivity_estimate": productivity,
        "breakdown": {
            "base_sleep_score": round(base, 1),
            "debt_penalty": round(debt_pen, 1),
            "caffeine_boost": round(caff, 1),
            "stress_penalty": round(s_pen, 1),
            "circadian_modifier": circ,
        }
    }

def power_nap_recommendation(hour: int, score: float) -> dict:
    """Suggests optimal nap window based on time of day and fatigue."""
    if score >= 75:
        return {"recommended": False, "reason": "Performance is good — no nap needed."}
    
    # Best nap window: 1–3 PM
    if 13 <= hour <= 15:
        best_time = f"{hour}:30 PM"
        urgency = "Now is ideal"
    elif hour < 13:
        best_time = "1:30 PM"
        urgency = f"In about {13 - hour}h"
    else:
        best_time = "Tomorrow 1:30 PM"
        urgency = "Too late today — napping now may disrupt night sleep"

    duration = 20 if score >= 50 else 30
    return {
        "recommended": True,
        "duration_min": duration,
        "best_time": best_time,
        "urgency": urgency,
        "tip": f"Set an alarm for {duration} min. Sleep in a dark, quiet space. Avoid caffeine 30 min after."
    }

def generate_recovery_plan(score, sleep_hours, debt, stress, hour, caffeine_mg) -> dict:
    plan = []
    activities = []
    points_earned = 0

    deficit = max(0, RECOMMENDED_SLEEP - sleep_hours)
    
    # Sleep schedule
    if deficit > 0:
        bedtime_shift = min(int(deficit * 30), 90)
        plan.append(f"Sleep {bedtime_shift} min earlier tonight to reduce your {deficit:.1f}h deficit.")
    
    if debt > 4:
        plan.append(f"You carry {debt:.1f}h of sleep debt. Aim for consistent 8–9h nights for the next {max(2, int(debt))} days.")

    # Consistent schedule
    plan.append("Maintain a consistent sleep/wake time — even on weekends. This anchors your circadian rhythm.")
    points_earned += 10

    # Caffeine
    if caffeine_mg > 300:
        plan.append("Reduce caffeine to under 300mg/day. Avoid caffeine after 2 PM to protect sleep onset.")
    
    # Stress
    if stress >= 6:
        plan.append("High stress detected. Try journaling or a 5-min wind-down routine before bed.")
        activities.append({"name": "Deep Breathing (4-7-8)", "duration": "5 min", "icon": "🫁",
                           "benefit": "Lowers cortisol", "points": 5})

    # Physical
    if score < 65:
        activities.append({"name": "Brisk Walk", "duration": "15 min", "icon": "🚶",
                           "benefit": "+10 alertness", "points": 10})
        activities.append({"name": "Light Stretching", "duration": "5 min", "icon": "🧘",
                           "benefit": "Reduces tension", "points": 5})

    # Sunlight
    if 7 <= hour <= 11:
        activities.append({"name": "Sunlight Exposure", "duration": "10 min", "icon": "☀️",
                           "benefit": "Boosts melatonin timing", "points": 5})
        plan.append("Get 10 min of morning sunlight — it resets your circadian clock and boosts serotonin.")

    # Evening wind-down
    if hour >= 20:
        activities.append({"name": "Screen-Free Wind-Down", "duration": "30 min", "icon": "📵",
                           "benefit": "Better sleep onset", "points": 5})
        plan.append("Dim lights and avoid blue-light screens for the next 30–60 min.")

    activities.append({"name": "Hydrate (500ml)", "duration": "Now", "icon": "💧",
                       "benefit": "+5 focus", "points": 3})

    return {"plan": plan, "activities": activities, "session_points": points_earned}

def compute_weekly_report(logs: list) -> dict:
    """Compute a 7-day sleep health summary."""
    week = logs[-7:] if len(logs) >= 7 else logs
    if not week:
        return None

    avg_sleep = round(sum(l["sleep_hours"] for l in week) / len(week), 2)
    avg_score = round(sum(l.get("cognitive_score", 50) for l in week) / len(week), 1)
    total_deficit = round(sum(max(0, RECOMMENDED_SLEEP - l["sleep_hours"]) for l in week), 1)

    # Trend: compare first half vs second half
    if len(week) >= 4:
        first_half = week[:len(week)//2]
        second_half = week[len(week)//2:]
        first_avg = sum(l["sleep_hours"] for l in first_half) / len(first_half)
        second_avg = sum(l["sleep_hours"] for l in second_half) / len(second_half)
        trend = "Improving" if second_avg > first_avg + 0.2 else (
            "Declining" if second_avg < first_avg - 0.2 else "Stable"
        )
    else:
        trend = "Insufficient data"

    # Suggestion
    if avg_sleep < 6:
        suggestion = f"Sleep {round(RECOMMENDED_SLEEP - avg_sleep + 0.5, 1)}h more per night — you're critically under-slept."
    elif avg_sleep < 7:
        suggestion = f"Try sleeping {round((RECOMMENDED_SLEEP - avg_sleep) * 60)}min earlier each night."
    elif avg_sleep >= 8:
        suggestion = "Great sleep duration! Focus on consistency and sleep quality."
    else:
        suggestion = "You're close to the target. Aim for 8h and a fixed wake time."

    return {
        "days_tracked": len(week),
        "avg_sleep_hours": avg_sleep,
        "avg_cognitive_score": avg_score,
        "total_sleep_deficit": total_deficit,
        "trend": trend,
        "suggestion": suggestion,
        "daily_scores": [{"date": l.get("date", "?"), "sleep": l["sleep_hours"],
                          "score": l.get("cognitive_score", 0)} for l in week]
    }

def update_rewards(data: dict, sleep_hours: float, completed_plan: bool) -> dict:
    rewards = data.get("rewards", {"points": 0, "streak": 0, "last_log_date": None})
    today = datetime.now().strftime("%Y-%m-%d")
    pts = 0

    if sleep_hours >= 8:
        pts += 10
    elif sleep_hours >= 7:
        pts += 5

    if completed_plan:
        pts += 5

    # Streak
    last = rewards.get("last_log_date")
    if last:
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        if last == yesterday:
            rewards["streak"] = rewards.get("streak", 0) + 1
            pts += rewards["streak"] * 2  # bonus for streak
        elif last != today:
            rewards["streak"] = 1
    else:
        rewards["streak"] = 1

    rewards["points"] = rewards.get("points", 0) + pts
    rewards["last_log_date"] = today
    rewards["points_today"] = pts

    # Tier
    total = rewards["points"]
    if total >= 500: rewards["tier"] = "Sleep Master 🏆"
    elif total >= 200: rewards["tier"] = "Peak Performer ⭐"
    elif total >= 80: rewards["tier"] = "Steady Achiever 🔄"
    else: rewards["tier"] = "Getting Started 🌱"

    return rewards

# ─────────────────────────────────────────────────────────
#  ROUTES
# ─────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/predict", methods=["POST"])
def predict():
    body = request.get_json()
    try:
        sleep_hours        = float(body.get("sleep_hours", 7))
        caffeine_mg        = float(body.get("caffeine_mg", 0))
        hours_since_caff   = float(body.get("hours_since_caffeine", 2))
        stress_level       = int(body.get("stress_level", 5))
        hour_of_day        = int(body.get("hour_of_day", 9))
        save_log           = bool(body.get("save_log", True))
    except (ValueError, TypeError) as e:
        return jsonify({"error": str(e)}), 400

    sleep_hours  = max(0, min(12, sleep_hours))
    caffeine_mg  = max(0, min(800, caffeine_mg))
    stress_level = max(1, min(10, stress_level))
    hour_of_day  = max(0, min(23, hour_of_day))

    data = load_data()

    debt_info = compute_sleep_debt(data["logs"])
    debt      = debt_info["sleep_debt_hours"]

    cog = compute_cognitive_score(sleep_hours, debt, caffeine_mg, hours_since_caff, stress_level, hour_of_day)
    rec = generate_recovery_plan(cog["cognitive_score"], sleep_hours, debt, stress_level, hour_of_day, caffeine_mg)
    nap = power_nap_recommendation(hour_of_day, cog["cognitive_score"])
    rxn = predict_reaction_time(cog["cognitive_score"])

    if save_log:
        log_entry = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%H:%M"),
            "sleep_hours": sleep_hours,
            "caffeine_mg": caffeine_mg,
            "stress_level": stress_level,
            "cognitive_score": cog["cognitive_score"],
            "fatigue_risk": cog["fatigue_risk"],
            "sleep_debt": debt
        }
        data["logs"].append(log_entry)
        data["rewards"] = update_rewards(data, sleep_hours, False)
        save_data(data)

    return jsonify({
        **cog,
        "sleep_debt": debt_info,
        "reaction_time": rxn,
        "power_nap": nap,
        "recovery": rec,
        "rewards": data["rewards"]
    })

@app.route("/api/history", methods=["GET"])
def history():
    data = load_data()
    weekly = compute_weekly_report(data["logs"])
    return jsonify({
        "logs": data["logs"][-30:],
        "weekly_report": weekly,
        "rewards": data["rewards"]
    })

@app.route("/api/weekly", methods=["GET"])
def weekly():
    data = load_data()
    report = compute_weekly_report(data["logs"])
    return jsonify(report or {"error": "No data yet. Log at least one sleep entry."})

@app.route("/api/complete_activity", methods=["POST"])
def complete_activity():
    body = request.get_json()
    points = int(body.get("points", 5))
    data = load_data()
    rewards = data.get("rewards", {"points": 0, "streak": 0})
    rewards["points"] = rewards.get("points", 0) + points
    total = rewards["points"]
    if total >= 500: rewards["tier"] = "Sleep Master 🏆"
    elif total >= 200: rewards["tier"] = "Peak Performer ⭐"
    elif total >= 80: rewards["tier"] = "Steady Achiever 🔄"
    else: rewards["tier"] = "Getting Started 🌱"
    data["rewards"] = rewards
    save_data(data)
    return jsonify(rewards)

@app.route("/api/clear", methods=["POST"])
def clear_data():
    save_data({"logs": [], "rewards": {"points": 0, "streak": 0, "last_log_date": None}})
    return jsonify({"status": "cleared"})

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "version": "2.0.0"})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
