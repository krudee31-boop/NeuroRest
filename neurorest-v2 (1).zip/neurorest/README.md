# NeuroRest 2.0 — Sleep Recovery & Cognitive Performance Predictor

A full-stack bioengineering application with 10 features for sleep tracking, cognitive prediction, and recovery planning.

## Quick Start

```bash
pip install -r requirements.txt
python app.py
# Open http://localhost:5000
```

## All 10 Features

| # | Feature | Description |
|---|---------|-------------|
| 1 | **Sleep Tracking** | Records daily sleep, tracks patterns, calculates deficit vs 8h recommended |
| 2 | **Sleep Debt Calculator** | Cumulative debt with 85% daily decay, estimates recovery nights |
| 3 | **Cognitive Performance Prediction** | Score (0–100) using sleep, caffeine, stress, circadian factors |
| 4 | **Fatigue Risk Detection** | Optimal / Mild / Moderate / Severe Fatigue levels |
| 5 | **Personalized Recovery Plan** | Adaptive text recommendations based on your inputs |
| 6 | **Smart Power Nap** | Optimal timing (1–3 PM window) and duration (20–30 min) |
| 7 | **Recovery Exercises** | Deep breathing, walking, stretching, sunlight exposure |
| 8 | **Reaction Time Estimation** | Predicted ms slowdown + driving safety assessment |
| 9 | **Reward & Gamification** | Points, streaks, 4-tier progression system |
| 10 | **Weekly Sleep Health Report** | Avg sleep, debt, score trend, charts, suggestion |

## Algorithm Details

### Cognitive Score Formula
```
Score = (Base_Sleep − Debt_Penalty + Caffeine_Boost − Stress_Penalty) × Circadian_Modifier

Base_Sleep     = sigmoid(sleep_hours / 8)  ×  100
Debt_Penalty   = min(35,  debt × 4.2)
Caffeine_Boost = min(12,  remaining_mg / 400 × 12)   # t½ = 5h
Stress_Penalty = exponential curve 1–25 pts
Circadian_Mod  = dual-Gaussian peaks at 10AM & 7PM  (0.70–1.15)
```

### Sleep Debt
```
debt(day) = (prev_debt + daily_deficit) × 0.85   # 15% daily clearance
```

### Reaction Time
```
predicted_ms = 250 + (1 - score/100)^1.6 × 350
```

## API Reference

### POST /api/predict
```json
{
  "sleep_hours": 6,
  "caffeine_mg": 120,
  "hours_since_caffeine": 2,
  "stress_level": 5,
  "hour_of_day": 9,
  "save_log": true
}
```

### GET /api/history
Returns last 30 log entries + weekly report + rewards

### GET /api/weekly
Returns 7-day aggregated report

### POST /api/complete_activity
```json
{ "points": 10 }
```

### POST /api/clear
Clears all stored data

## Project Structure
```
neurorest/
├── app.py              # Flask backend (all algorithms)
├── requirements.txt
├── README.md
├── sleep_data.json     # Auto-created on first run
└── templates/
    └── index.html      # Full SPA frontend (4 pages)
```
